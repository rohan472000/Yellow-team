package project5_com;
import java.sql.*;
public class connection_provide {
 
	public static Connection getCon()
	{
		Connection con=null;
		String url="jdbc:mysql://localhost:3306/stock";
		String username="root";
		String password="rohit";
		System.out.println("connected nhi");
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection(url,username,password);
			System.out.println("connected");
			return con;
		} catch (Exception e) {
			System.out.println(e);
			return null;// TODO: handle exception
		}
		
	}
}
